import { Link } from 'react-router-dom';
import { FiGithub, FiLinkedin, FiTwitter, FiMail } from 'react-icons/fi';

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-gray-100 dark:bg-dark-card">
      <div className="container-custom py-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <Link to="/" className="text-xl font-bold text-accent">
              MV
            </Link>
            <p className="mt-2 text-sm">Building innovative web solutions</p>
          </div>
          
          <div className="flex items-center gap-6">
            <a 
              href="https://github.com/yourusername" 
              target="_blank" 
              rel="noopener noreferrer"
              className="hover:text-accent transition-colors"
              aria-label="GitHub"
            >
              <FiGithub size={20} />
            </a>
            <a 
              href="https://linkedin.com/in/yourusername" 
              target="_blank" 
              rel="noopener noreferrer"
              className="hover:text-accent transition-colors"
              aria-label="LinkedIn"
            >
              <FiLinkedin size={20} />
            </a>
            <a 
              href="https://twitter.com/yourusername" 
              target="_blank" 
              rel="noopener noreferrer"
              className="hover:text-accent transition-colors"
              aria-label="Twitter"
            >
              <FiTwitter size={20} />
            </a>
            <a 
              href="mailto:your.email@example.com" 
              className="hover:text-accent transition-colors"
              aria-label="Email"
            >
              <FiMail size={20} />
            </a>
          </div>
        </div>
        
        <div className="mt-8 pt-4 border-t border-gray-200 dark:border-gray-700">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-gray-500">
              © {currentYear} Manas Verma. All rights reserved.
            </p>
            <div className="mt-4 md:mt-0 flex gap-4">
              <Link to="/" className="text-sm hover:text-accent transition-colors">Home</Link>
              <a href="#about" className="text-sm hover:text-accent transition-colors">About</a>
              <Link to="/blog" className="text-sm hover:text-accent transition-colors">Blog</Link>
              <a href="#contact" className="text-sm hover:text-accent transition-colors">Contact</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}